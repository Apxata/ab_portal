MOD [b]Anti-spam by CleanTalk[/b]
Version: 2.18

Anti-spam by CleanTalk mod with protection against spam bots and manual spam.
No Captcha, no questions, no counting animals, no puzzles, no math.

[b]Features[/b]
[list]
	[li]Deny signups of spam bots[/li]
	[li]If necessary require administrator approval for new members[/li]
	[li]Antispam test for first post on board for Newly registered members[/li]
[/list]

The mod is a client application for cloud anti-spam [url=http://cleantalk.org/]CleanTalk.org[/url], which are daily protects 5k web-sites from spam bots.
Also you can use CleanTalk app for iPhone/iPad to control anti-spam service on web-site or control comments, signups, contacts and orders.

[b]Admin Settings[/b]
Mod has admin settings on page Admin - Features and options - Configuration - Modification settings

[b]Compatibility Notes[/b]
SMF 2.0 and up

[b]License[/b]
[url=http://www.gnu.org/copyleft/gpl.html]GNU General Public License[/url]

[b]Changelog[/b]
See on [url=https://github.com/CleanTalk/smf-antispam/blob/master/CHANGELOG]Github[/url]


[url=http://cleantalk.org/]CleanTalk site[/url]

[url=https://github.com/CleanTalk/smf-antispam]Github repository[/url]


